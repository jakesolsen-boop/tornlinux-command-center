# TornLinux 1.1.0

## Overview
First feature update after the 1.0.1 stabilization pass.

## Versioning Scheme
- Major: Breaking changes / architecture overhaul
- Minor: Feature additions
- Patch: Bug fixes / stability improvements

## Changes in 1.1.0

### Core Fixes
- Removed happiness component from the active header surface
- Fixed header prop contract mismatch between App and Header component
- Standardized current package surfaces to 1.1.0

### Status System
- Replaced the flat status string with a structured status object
- Added a single status chip instead of separate status meters
- Added dynamic status icon swapping for okay, hospital, jail, travel, abroad, and offline states
- Added countdown display when Torn provides a timed `until` status

### Build System
- Added required `prepare-live-build` step to the implementation guide
- Added `preflight-check.sh` to verify renderer output and staged packaged app before ISO build
- Added release notes, version file, and checksum manifest

### Electron Stability
- Kept fallback window show logic
- Kept renderer failure logging
- Kept crash detection hooks

## Known Limitations
- TornStats integration still needs full live-image validation
- Status countdown updates on refresh cadence, not per-second client ticks

## Next Targets
- Optional status live second-by-second ticking in the renderer
- Boot diagnostics overlay
- Release automation for checksums and manifest updates
