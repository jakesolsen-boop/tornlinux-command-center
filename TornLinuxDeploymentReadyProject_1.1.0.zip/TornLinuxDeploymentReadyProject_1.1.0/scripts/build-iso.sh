#!/bin/bash
set -euo pipefail

cd live-build
sudo lb build
