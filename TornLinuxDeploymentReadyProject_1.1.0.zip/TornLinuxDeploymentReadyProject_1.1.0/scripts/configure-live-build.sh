#!/bin/bash
set -euo pipefail

cd live-build

lb config   --distribution bookworm   --debian-installer false   --archive-areas "main contrib non-free non-free-firmware"   --binary-images iso-hybrid   --bootappend-live "boot=live components quiet splash username=tornuser"
