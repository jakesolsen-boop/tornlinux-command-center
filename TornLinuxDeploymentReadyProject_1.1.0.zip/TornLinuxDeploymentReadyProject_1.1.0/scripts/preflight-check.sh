#!/bin/bash
set -euo pipefail

echo "Running TornLinux preflight checks..."

if [ ! -f "dist/renderer/index.html" ]; then
  echo "ERROR: Renderer not built. Run: npm run build:renderer"
  exit 1
fi

if [ ! -f "live-build/config/includes.chroot/opt/tornlinux-app/TornLinux" ]; then
  echo "ERROR: Packaged app not staged. Run: ./scripts/prepare-live-build.sh"
  exit 1
fi

echo "Preflight checks passed."
